using System;
using System.Collections;

 
public abstract class Shape {
    public abstract void Move(double tx, double ty);
    // Shape translation
    public abstract void Rotate(double rt, double rx, double ry);
    // Shape rotation on a point (x,y)
    public abstract void Print();
    // Print shape's definitive information
}

 
public class Point : Shape {
    // x and y coordinates 
    public double mx, my;

 
    public Point(double x, double y){
        this.mx = x;
        this.my = y;
    }

 
    public override void Move(double tx, double ty){
        //translate the object based on how much to move in x and y axis
        this.mx += tx;
        this.my += ty;
    }

 
    public override void Rotate(double rt, double rx, double ry){
        double dx = this.mx - rx;
        double dy = this.my - ry;
        double cn = Math.Cos(rt);
        double sn = Math.Sin(rt);

 
        // rotate and roundoff
        this.mx = Math.Round( (dx * cn) - (dy * sn) + rx, 5);
        this.my = Math.Round( (dx * sn) + (dy * cn) + ry, 5);
    }

 
    public override void Print(){
        Console.WriteLine("point at ({0}, {1})", this.mx, this.my);
    }

 
}

 
public class Line : Shape {
    // line can defined by 2 points
    public Point ms, me;

 
    public Line(double sx, double sy, double ex, double ey){
        this.ms = new Point(sx, sy);
        this.me = new Point(ex, ey);
    }

 
    public Point GetMidpoint(){
        return new Point( (ms.mx + me.mx)/2, (ms.my + me.my)/2);
    }

 
    public override void Move(double tx, double ty){
        //move both points together, so the line moves
        this.ms.Move(tx, ty);
        this.me.Move(tx, ty);
    }

 
    public override void Rotate(double rt, double rx, double ry){
        //rotate the line about it
        this.ms.Rotate(rt, rx, ry);
        this.me.Rotate(rt, rx, ry);
    }

 
    public override void Print(){
        Console.WriteLine("line with points:");
        Console.Write("starting ");
        this.ms.Print();
        Console.Write("ending ");
        this.me.Print();
    }

 
}

 
public class Circle : Shape {
    //a circle contains a center point and a radius
    public Point mc;
    public double mr;

 
    public Circle(double cx, double cy, double cr){
        this.mc = new Point(cx, cy);
        this.mr = cr;
    }

 
    public override void Move(double tx, double ty){
        this.mc.Move(tx, ty);
    }

 
    public override void Rotate(double rt, double rx, double ry){
        this.mc.Rotate(rt, rx, ry);
    }

 
    public override void Print(){
        Console.Write("circle or radius {0} with center ", this.mr);
        this.mc.Print();
    }
}

 
public class Aggregate : Shape {
    public ArrayList ma;

 
    public Aggregate(){
        this.ma = new ArrayList();
    }

 
    public void AddShape(Shape ns){
        this.ma.Add(ns);
    }

 
    public override void Move(double tx, double ty){
        // translate every shapes the same way
        foreach(Shape s in this.ma){
            s.Move(tx, ty);
        }
    }

 
    public override void Rotate(double rt, double rx, double ry){
        // rotate every shapes the same way
        foreach(Shape s in this.ma){
            s.Rotate(rt, rx, ry);
        }
    }

 
    public override void Print(){
        // print shape details
        foreach(Shape s in this.ma){
            s.Print();
        }
    }

 
}

 
public class Program {

 
    public static void Main(string[] args) {
        Point p1 = new Point(0, 1);
        p1.Move(0, 1);
        p1.Print();
        //rotate clockwise 90 degress
        p1.Rotate(-Math.PI/2, 0, 0);
        p1.Print();
        //rotate anti clockwise 45 degrees
        p1.Rotate(Math.PI/4, 0, 0);
        p1.Print();

 
        //rotate about on point 
        p1.Rotate(Math.PI, p1.mx, p1.my);
        p1.Print();

 
        Line l1 = new Line(0, 0, 1, 1); 
        //line with gradient 1, y intercept 0
        l1.Move(1, 0); 
        //shift line to the right
        l1.Print();

 
        l1.Move(-1, 0); 
        //shift line back to the right
        l1.Print();

 
        l1.Rotate(Math.PI, 0, 0); 
        // 180 rotate about origin (line will have same starting but diff ending)
        l1.Print();

 
        Point l1mp = l1.GetMidpoint();
        //rotating a line about its midpoint should swap the starting and ending point
        l1.Rotate(Math.PI, l1mp.mx, l1mp.my);
        l1.Print();

 
        Circle c1 = new Circle(1, 1, 1); 
        //radius centered at (1, 1) with radius 1
        c1.Print();
        c1.Move(-2, -2);
        c1.Print();

 
        c1.Rotate(Math.PI, 0, 0);
        c1.Print();

 
        c1.Rotate(Math.PI, c1.mc.mx, c1.mc.my); 
        // won't change anything
        c1.Print();

 
        Aggregate a1 = new Aggregate();
        a1.AddShape(new Point(1, 2));
        a1.AddShape(new Circle(1, 1, 1));
        a1.AddShape(new Line(1, 1, 2, 2));
        a1.Print();

 
        a1.Move(1, 1);
        a1.Print();
        a1.Move(-1, -1);
        a1.Print();

 
        a1.Rotate(Math.PI, 0, 0);
        a1.Print();
    }
}

